import torch
from tqdm import tqdm
from copy import deepcopy
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import loss_func
from orth import dbt_orth, ker_orth


def train_step(trainloader, model, teacher_model,loss_fn, model_optimizer, device):
    model.to(device)
    distillation_loss_fn = loss_func.DistillationLoss(alpha=0.5).cuda()
    initial_lambdas=(0.5, 0.01)
    lambda_distill, lambda_orth = initial_lambdas
    # 使用GA优化权重
    lambda_distill, lambda_orth = genetic_algorithm_optimize(
        model, trainloader, teacher_model, distillation_loss_fn, device, generations=5, population_size=10
    )

    teacher_model=teacher_model.eval().cuda()
    
    for data, label, idx in trainloader:
        data, label = data.to(device), label.to(device)
        if data.size(0) <= 1:
            continue

        # model train
        model.train()
        model_optimizer.zero_grad()
        output = model(data)
        # diff = dbt_orth(model)
        with torch.no_grad():
                 teacher_out = teacher_model(data)
        ce_loss,distillation_loss = distillation_loss_fn(output, teacher_out, label)
        diff = ker_orth(model)
        loss_orth = lambda_orth* diff
        # p = torch.softmax(output, dim=1)
        # ps = (p ** 2) / (p ** 2).sum(dim=1, keepdim=True)
        # loss1 = loss_fn(ps, label)    # sharpening cross entropy loss
        # loss1 = loss_fn(output, label)+0.01*distill_loss   # normal cross entropy loss
        loss1 =ce_loss+lambda_distill*distillation_loss+loss_orth
        loss1.backward()
        model_optimizer.step()

    if hasattr(torch.cuda, 'empty_cache'):
        torch.cuda.empty_cache()
def genetic_algorithm_optimize(model, trainloader, teacher_model, distillation_loss_fn, device, generations=5, population_size=10):
    """
    使用遗传算法优化 distillation_loss 和 loss_orth 的系数
    """
    import numpy as np

    # 初始化种群
    population = np.random.uniform(low=0.01, high=0.5, size=(population_size, 2))  # 初始化 [lambda_distill, lambda_orth]
    fitness_scores = np.zeros(population_size)

    for generation in range(generations):
        print(f"GA Generation {generation + 1}/{generations}")

        # 评估适应度
        for i in range(population_size):
            lambda_distill, lambda_orth = population[i]
            fitness_scores[i] = evaluate_fitness(
                model, trainloader, teacher_model, distillation_loss_fn, device, lambda_distill, lambda_orth
            )

        # 选择（保留适应度最高的一半）
        top_indices = np.argsort(fitness_scores)[: population_size // 2]
        parents = population[top_indices]

        # 交叉（随机选择父代生成子代）
        offspring = []
        for _ in range(population_size // 2):
            p1, p2 = parents[np.random.choice(len(parents), size=2, replace=False)]
            crossover_point = np.random.randint(2)
            child = np.concatenate([p1[:crossover_point], p2[crossover_point:]])
            offspring.append(child)

        # 变异（随机微调权重）
        offspring = np.array(offspring)
        mutation = np.random.uniform(-0.1, 0.1, offspring.shape)
        offspring += mutation
        offspring = np.clip(offspring, 0.01, 1.0)  # 保证权重在合理范围内

        # 更新种群
        population = np.vstack([parents, offspring])

    # 返回最优权重
    best_index = np.argmax(fitness_scores)
    return population[best_index]


def evaluate_fitness(model, trainloader, teacher_model, distillation_loss_fn, device, lambda_distill, lambda_orth):
    """
    评估当前权重组合的适应度（总损失越小越好）
    """
    model.eval()
    teacher_model.eval()  # 确保 teacher_model 处于评估模式
    model.to(device)  # 确保 model 在正确的设备上
    teacher_model.to(device)  # 确保 teacher_model 在正确的设备上

    total_loss = 0.0
    num_batches = 0

    with torch.no_grad():
        for data, label, idx in trainloader:
            data, label = data.to(device), label.to(device)  # 将数据移到正确的设备
            if data.size(0) <= 1:
                continue

            # 模型输出
            output = model(data)
            diff = dbt_orth(model)
            teacher_out = teacher_model(data)

            # 计算损失
            ce_loss, distillation_loss = distillation_loss_fn(output, teacher_out, label)
            loss_orth = lambda_orth * diff
            total_loss += ce_loss.item() + lambda_distill * distillation_loss.item() + loss_orth.item()
            num_batches += 1

    # 适应度是总损失的负数（越小越好）
    return -total_loss / num_batches


def model_bias(model, model_dict):
    local_dict = deepcopy(model.state_dict())
    update = dict()
    for k, v in model_dict.items():
        v = v.to(torch.device('cpu'))
        local_dict[k] = local_dict[k].to(torch.device('cpu'))
        update[k] = local_dict[k] - v
    return update

def validate(loader, model, criterion, device):
    total_loss = 0.0
    total = 0
    accuracy = 0.0
    precision = 0.0
    recall = 0.0
    f1 = 0.0

    model.eval()
    model.to(device)

    with torch.no_grad():
        for idx, (inputs, targets, id) in enumerate(loader):
            inputs = inputs.to(device)
            targets = targets.to(device).long()
            outputs = model(inputs)
            preds = outputs.argmax(dim=1)

            total_loss += criterion(outputs, targets).item()
            accuracy += accuracy_score(targets.cpu(), preds.cpu())
            precision += precision_score(targets.cpu(), preds.cpu(), average='macro')
            recall += recall_score(targets.cpu(), preds.cpu(), average='macro')
            f1 += f1_score(targets.cpu(), preds.cpu(), average='macro')

            total += len(inputs)

    num_batches = idx + 1
    if num_batches > 0:
        acc = accuracy / num_batches * 100
        precision = precision / num_batches * 100
        recall = recall / num_batches * 100
        f1 = f1 / num_batches * 100
        avg_loss = total_loss / num_batches
    else:
        acc = precision = recall = f1 = avg_loss = 0.0

    return acc, precision, recall, f1, avg_loss
