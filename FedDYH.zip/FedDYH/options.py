import argparse


def args_parser():
    parser = argparse.ArgumentParser()
    # FL settings
    parser.add_argument('--num_worker', type=int, default=20,
                        help='number of workers {20, 100}')
    parser.add_argument('--choosen_fraction', type=float, default=0.2,
                        help='fraction of clients selected every round {0.05, 0.25}')
    parser.add_argument('--B', type=int, default=32,
                        help='batch size')
    parser.add_argument('--R', type=int, default=100,
                        help='global rounds {100, 200}')
    parser.add_argument('--E', type=int, default=1)
    parser.add_argument('--lr', type=int, default=0.01)
    parser.add_argument('--dir_alpha', type=float, default=0.5,
                        help='dirichlet distribution')
    parser.add_argument('--iid', type=bool, default=False,
                        help='data distribution')
    parser.add_argument('--seed', type=int, default=666666,
                        help='random seed')
    parser.add_argument('--rule', type=str, default='fedavg')

    # dataset setiing
    parser.add_argument('--dataset', type=str, default='mnist')
    parser.add_argument('--num_class', type=int, default=10)

    # training setting
    parser.add_argument('--model', type=str, default='CNN1')
    parser.add_argument('--criterion', type=str, default='CE')
    parser.add_argument('--loss', type=str, default='CE',
                        help='{CE, SCE}')
    parser.add_argument('--optimizer', type=str, default='SGD',
                        help='optimizer = {SGD, Adam}')
    parser.add_argument('--min_threshold', type=float, default=0.5,
                        help = 'minimum confidence threshold')
    parser.add_argument('--max_threshold', type=float, default=0.95,
                        help = 'maximum confidence threshold')

    # noise setting
    parser.add_argument('--noise', type=bool, default=True)
    parser.add_argument('--noise_ratio', type=float, default=0,
                        help = 'noisy clients selection ratio')
    parser.add_argument('--noise_lowbound', type=float, default=0,
                        help='noise lower bound {0.2, 0.4, 0.6}')
    parser.add_argument('--noise_type', type=str, default='symmetric')

    return parser.parse_args()