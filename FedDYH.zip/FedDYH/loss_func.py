import torch
import torch.nn as nn
import torch.nn.functional as F
def loss_fn_(loss):
    criterion = nn.CrossEntropyLoss()
    if loss == 'CE':
        def loss_fn(output, target):
            loss_ = criterion(output, target)
            return loss_

    elif loss == 'SCE':
        def loss_fn(output, target):
            loss_ = criterion(output, target) + criterion(target, output)
            return loss_
    elif loss == 'KDCE':
        def loss_fn(output, target):
            loss_=DistillationLoss(alpha=0.5)
            return loss_
    else:
        pass
    return loss_fn

def cross_entropy():
    def loss_fn(output, target):
            loss_ = F.cross_entropy(output, target)
            return loss_
    return loss_fn

def L1loss( predict, target):
    """
    :param predict: model prediction for original data
    :param target: model prediction for mildly augmented data
    :return: loss
    """
    loss_f = nn.L1Loss(reduction='mean')
    l1_loss = loss_f(predict, target)
    return l1_loss

def L2loss(predict, target):
    """
    :param predict: model prediction for original data
    :param target: model prediction for mildly augmented data
    :return: loss
    """
    loss_f_mse = nn.MSELoss(reduction='mean')
    loss_mse = loss_f_mse(predict, target)
    return loss_mse

def js(p_output, q_output):
    """
    :param predict: model prediction for original data
    :param target: model prediction for mildly augmented data
    :return: loss
    """
    KLDivLoss = nn.KLDivLoss(reduction='mean')
    log_mean_output = ((p_output + q_output) / 2).log()
    return (KLDivLoss(log_mean_output, p_output) + KLDivLoss(log_mean_output, q_output)) / 2
class DistillationLoss(nn.Module):
    def __init__(self, alpha=0.5, num_classes=10, epsilon=0.1):
        """
        Args:
            alpha (float): 交叉熵损失与蒸馏损失的加权系数。
            num_classes (int): 数据集的类别数。
            epsilon (float): 标签平滑系数。
        """
        super(DistillationLoss, self).__init__()
        self.alpha = alpha
        self.num_classes = num_classes
        self.epsilon = epsilon

    def z_score(self, logits):
        """对 logits 进行标准化 (Z 分数标准化)"""
        mean = logits.mean(dim=-1, keepdim=True)
        stdv = logits.std(dim=-1, keepdim=True)
        return (logits - mean) / (1e-7 + stdv)

    def compute_temperature(self, logits):
        """根据 logits 的加权标准差动态计算温度"""
        probs = F.softmax(logits, dim=1)
        mean = (logits * probs).sum(dim=1, keepdim=True)
        variance = (probs * (logits - mean) ** 2).sum(dim=1, keepdim=True)
        return torch.sqrt(variance + 1e-7)  # 避免数值问题

    def forward(self, student_outputs, teacher_outputs, labels):
        # 对 logit 进行标准化 (Z 分数)
        student_outputs = self.z_score(student_outputs)
        teacher_outputs = self.z_score(teacher_outputs)

        # 动态计算温度
        temperature = self.compute_temperature(teacher_outputs)

        # 计算蒸馏损失
        student_probs = F.log_softmax(student_outputs / temperature, dim=1)
        teacher_probs = F.softmax(teacher_outputs / temperature, dim=1)
        distillation_loss = F.kl_div(student_probs, teacher_probs, reduction="batchmean") * (temperature ** 2).mean()

        # 标签平滑的交叉熵损失
        log_probs = F.log_softmax(student_outputs, dim=1)
        targets = torch.zeros_like(log_probs).scatter_(1, labels.unsqueeze(1), 1)
        targets = (1 - self.epsilon) * targets + self.epsilon / self.num_classes
        ce_loss = (-targets * log_probs).sum(dim=1).mean()

        # 合并损失
        # loss = self.alpha * ce_loss + (1 - self.alpha) * distillation_loss
        return ce_loss,distillation_loss
def kl_div(input, target):
    KLDivLoss = nn.KLDivLoss(reduction='mean')
    return KLDivLoss(input,target)