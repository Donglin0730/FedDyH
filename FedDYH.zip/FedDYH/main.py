import gc
import copy
import numpy as np
import torch
import loss_func
import models
from client import Clients
from training import  validate
from datasets import data_loading
from options import args_parser
from torch.utils.data import DataLoader, random_split
from utils import (trainset_split, iid_sampling, set_random_seed, data_noisifying,
                   sample_by_class, n_iid_sampling, Clothing_sampling, random_sampling, FedAvg, noniid_sampling)


def main(args):
    device = torch.device('cuda:0')
    torch.cuda.empty_cache()
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

    # data initialization
    trainset, testset = data_loading(args)
    testloader = DataLoader(testset, batch_size=args.B, shuffle=True,num_workers=4)
    original_size = int(0.2 * len(trainset))
    extra_size = len(trainset) - original_size
    original_set, extra_set = random_split(trainset, [original_size, extra_size])

    original_indices = original_set.indices if hasattr(original_set, 'indices') else list(range(len(original_set)))
    original_data = [trainset[i][0] for i in original_indices]
    original_targets = [trainset[i][1] for i in original_indices]
    a, b = 0, len(original_targets)
    original_class_idcs = sample_by_class(original_targets, args.num_class, a, b)

    extra_indices = extra_set.indices if hasattr(extra_set, 'indices') else list(range(len(extra_set)))
    extra_data = [trainset[i][0] for i in extra_indices]
    extra_targets = [trainset[i][1] for i in extra_indices]

    train_data = original_data + extra_data
    train_targets = original_targets + extra_targets

    if args.iid and args.dataset != 'clothing1m':
        client_idcs = iid_sampling(original_class_idcs, args.num_worker, args.seed)
    elif not args.iid and args.dataset != 'clothing1m':
        client_idcs = n_iid_sampling(original_class_idcs, len(original_data), args.num_worker, args.seed)
    else:
        client_idcs = Clothing_sampling(len(original_data), args.num_worker)

    if args.noise:
        original_client_data, original_client_targets, num_data = trainset_split(original_targets, original_data, client_idcs, args.num_worker)
        print('Original data number:', num_data)
        noisy_client_targets, noise_level = data_noisifying(args, original_client_targets, num_data)
        print('Original noise levels:', noise_level)

    clients = [Clients(original_client_data[i], noisy_client_targets[i], client_idcs[i]) for i in range(args.num_worker)]

    # parameters initialization
    if args.model == 'CNN1':
        model = models.CNN1()
    elif args.model == 'CNN2':
        model = models.CNN2()
    elif args.model == 'resnet18':
        model = models.resnet18()
    elif args.model == 'resnet34':
        model = models.resnet34()
    elif args.model == 'resnet50':
        model = models.resnet50(pretrained=True)
    else:
        print('model error')



    if args.criterion == 'CE':
        criterion = torch.nn.CrossEntropyLoss()
    elif args.criterion == 'KDCE':
        criterion = loss_func.DistillationLoss(alpha=0.5)
    model.adjust_classifier(10)
    global_model = copy.deepcopy(model)
    global_dict = global_model.state_dict()

    loss_fn = loss_func.cross_entropy()
    number_select = int(args.num_worker * args.choosen_fraction)
    list_test_acc = []

    # federated learning
    for t in range(args.R):
        print('=========The {:d} round========='.format(t + 1))
        a = len(original_targets) + t / args.R * len(extra_targets)
        b = a + 1 / args.R * len(extra_targets)
        dynamic_class_idcs = sample_by_class(train_targets, args.num_class, int(a), int(b))

        if args.iid and args.dataset != 'clothing1m':
            dynamic_idcs = random_sampling(dynamic_class_idcs, args.num_worker, args.seed)
        elif not args.iid and args.dataset != 'clothing1m':
            # dynamic_idcs = n_iid_sampling(dynamic_class_idcs, int(b-a), args.num_worker, args.seed)
            # 使用 Dirichlet 分布进行非独立同分布（non-IID）采样
            alpha = args.dir_alpha # 需要在 args 中添加 alpha 参数，例如 0.5
            # 确保 train_targets 是 NumPy 数组
            train_targets = np.array(train_targets)

            # Flatten dynamic_class_idcs 并确保其为整数
            flattened_indices = np.hstack(dynamic_class_idcs).astype(int)

            # 索引操作
            train_labels = train_targets[flattened_indices]

            dynamic_idcs = noniid_sampling(train_labels, alpha, args.num_worker, args.seed)

        else:
            dynamic_idcs = Clothing_sampling(b-a, args.num_worker)

        if args.noise:
            dynamic_data, dynamic_targets, dynamic_num = trainset_split(train_targets, train_data, dynamic_idcs, args.num_worker)
            noisy_dynamic_targets, noise_level = data_noisifying(args, dynamic_targets, dynamic_num)
            # print('Real-time injected noise levels:', noise_level)

        # for i in range(args.num_worker):
        #     clients[i].dynamic_update(global_model,dynamic_data[i], noisy_dynamic_targets[i], dynamic_idcs[i])

        selected = np.random.choice(args.num_worker, number_select, replace=False)
        print('Selected clients:', selected)

        local_update, datasize = {},  []
        for i in range(len(selected)):
            local_model = copy.deepcopy(global_model)
            teacher_model=copy.deepcopy(global_model)  
             # 每个客户端基于全局模型初始化
            clients[selected[i]].dynamic_update(global_model, dynamic_data[selected[i]], noisy_dynamic_targets[selected[i]], dynamic_idcs[selected[i]])
            clients[selected[i]].train(args, local_model,teacher_model, loss_fn, device, local_update, [selected[i]], t)
            datasize_value = clients[selected[i]].upload()
            print(f"Client {selected[i]} datasize:", datasize_value)
            datasize.append(datasize_value)






        print('Selected clients datasize:',  datasize)
        total_data = sum(datasize)

        if args.rule == 'fedavg':
            alpha = [datasize[i] / total_data for i in range(len(selected))]
            global_dict = FedAvg(selected, alpha, global_dict, local_update)
            global_model.load_state_dict(global_dict, strict=False)
        


        global_acc = validate(testloader, global_model, criterion, device)
        list_test_acc.append(round(global_acc[0], 2))
        print('Test accuracy:{:.2f}%'.format(global_acc[0]))
    print('Max test accuracy:{:.2f}%'.format(max(list_test_acc)))
    print('Full test accuracy:', list_test_acc)

if __name__ == '__main__':
    args = args_parser()
    gc.collect()
    set_random_seed(args.seed)
    main(args)