import torch
import torch.nn as nn
from torch.nn import functional as F

from utils import stable_cosine_distance

import logging

logger = logging.getLogger(__name__)


class CosineClassifier(nn.Module):
    def __init__(self, features_dim):
        super(CosineClassifier, self).__init__()
        self.device = 'cuda'
        self.n_classes = 0
        self._weights = nn.ParameterList([])
        self.proxy_per_class = 10
        self.features_dim = features_dim
        self.bias = None
        self.scaling = 3.
        self.gamma = 1.

        # adaptive alpha in eqn. 6. New alpha vectors are added in func `self.add_classes()`
        self._alpha = nn.ParameterList([])
        # self._alpha = nn.Parameter(torch.zeros(self.n_classes))
        # nn.init.normal_(self._alpha)  # 初始化 alpha 参数
        # self.register_buffer('_alpha', )

    @property
    def weights(self):
        return torch.cat([_weight for _weight in self._weights])

    @property
    def new_weights(self):
        return self._weights[-1]

    @property
    def alpha(self):
        return torch.cat([_alpha for _alpha in self._alpha])

    def forward(self, features):
        features = self.scaling * F.normalize(features, p=2, dim=-1)
        weights = self.scaling * F.normalize(self.weights, p=2, dim=-1)
        raw_similarities = -stable_cosine_distance(features, weights)

        if self.proxy_per_class > 1:
            n_classes = raw_similarities.shape[1] // self.proxy_per_class
            
            bsz = raw_similarities.shape[0]
            simi_per_class = raw_similarities.view(bsz, n_classes, self.proxy_per_class)

            # print(f"alpha shape: {self.alpha.shape},simi_per_class shape: {simi_per_class.shape}")
    
            # attentions = F.softmax(self.alpha.unsqueeze(0).expand(bsz, -1) * simi_per_class, dim=-1)
            attentions = F.softmax(self.alpha.unsqueeze(1).repeat(1, self.proxy_per_class) * simi_per_class, dim=-1)
            logits = (simi_per_class * attentions).sum(-1)
        else:
            logits = raw_similarities

        return logits
    def add_classes(self, target_classes):
        logger.info(f'add_class: old classes: {self.n_classes}, new classes: {target_classes}')
        if target_classes == self.n_classes:
            logger.info(f'No need to adjust classes. Current classes: {self.n_classes}, Target classes: {target_classes}')
            return

        if target_classes > self.n_classes:
            # 添加新类别
            n_classes_to_add = target_classes - self.n_classes
            new_weights = nn.Parameter(torch.zeros(self.proxy_per_class * n_classes_to_add, self.features_dim))
            nn.init.kaiming_normal_(new_weights, nonlinearity="linear")
            self._weights.append(new_weights)

            new_alpha = nn.Parameter(torch.zeros(n_classes_to_add))
            nn.init.normal_(new_alpha)
            self._alpha.append(new_alpha)
        elif target_classes < self.n_classes:
            # 减少类别
            n_classes_to_keep = target_classes
            self._weights = self._weights[:n_classes_to_keep]
            self._alpha = nn.ParameterList(self._alpha[:n_classes_to_keep])

        # 同步类别数
        self.n_classes = target_classes
        self.to(self.device)
        logger.info(f"Updated weights shape: {self.weights.shape}, alpha shape: {self.alpha.shape}")


    # def add_classes(self, target_classes):
    #     logger.info(f'add_class: old classes: {self.n_classes}, new classes: {target_classes}')
    #     print(f"add_class log: old classes: {self.n_classes}, new classes: {target_classes}")
        
    #     if target_classes == self.n_classes:
    #         logger.info(f'No need to adjust classes. Current classes: {self.n_classes}, Target classes: {target_classes}')
    #         return

    #     if target_classes > self.n_classes:
    #         # 增加新类别
    #         if len(self._alpha) > 0:
    #             print(f" add Alpha size: {self.alpha.size(0)}, Expected n_classes: {target_classes}")
    #             print(f" add_Alpha size: {self._alpha}, Expected n_classes: {target_classes}")

    #         n_classes_to_add = target_classes - self.n_classes
    #         new_weights = nn.Parameter(torch.zeros(self.proxy_per_class * n_classes_to_add, self.features_dim))
    #         nn.init.kaiming_normal_(new_weights, nonlinearity="linear")
    #         self._weights.append(new_weights)

    #         new_alpha = nn.Parameter(torch.zeros(n_classes_to_add))  # 为新类别添加新的 alpha
    #         nn.init.normal_(new_alpha)
            
    #         self._alpha.append(new_alpha)  # 初始化为空列表并添加 new_alpha


            
        # elif target_classes < self.n_classes:
        #     if len(self._alpha) > 0:
        #         print(f" reduce Alpha size: {self.alpha.size(0)}, Expected n_classes: {target_classes}")
        #         print(f" reduce_Alpha size: {self._alpha}, Expected n_classes: {target_classes}")

        #     # 减少类别
        #     n_classes_to_keep = target_classes
        #     self._weights = self._weights[:self.proxy_per_class * n_classes_to_keep]
        #     # 确保索引不越界
        #     if len(self._alpha) >= n_classes_to_keep:
        #         self._alpha = nn.ParameterList([self._alpha[i] for i in range(n_classes_to_keep)])

            

        # self.n_classes = target_classes
         
        # self.to(self.device)
        # torch.cuda.empty_cache()



    def _reduce_proxies(self, similarities):
        """
          similarities : (batch_size, n_classes * proxy_per_class)
             return    : (batch_size, n_classes)
        """
        n_classes = similarities.shape[1] / self.proxy_per_class
        assert n_classes.is_integer(), (similarities.shape[1], self.proxy_per_class)
        n_classes = int(n_classes)
        bsz = similarities.shape[0]

        simi_per_class = similarities.view(bsz, n_classes, self.proxy_per_class)

        # 1. adaptive balanced softmax
        # attentions = F.softmax(self.alpha.unsqueeze(1).tile(1, self.proxy_per_class) * simi_per_class, dim=-1)
        attentions = F.softmax(self.alpha.unsqueeze(1).repeat(1, self.proxy_per_class) * simi_per_class, dim=-1)

        # 2. vanilla softmax
        # attentions = F.softmax(self.gamma * simi_per_class, dim=-1)

        return (simi_per_class * attentions).sum(-1)


if __name__ == "__main__":
    cosincls = CosineClassifier(features_dim=512)
    # print(cosincls.__dict__)
    cosincls.add_classes(10)
# import torch
# import torch.nn as nn
# from torch.nn import functional as F

# from utils import stable_cosine_distance

# import logging
# logger = logging.getLogger(__name__)


# class CosineClassifier(nn.Module):
#     def __init__(self, features_dim):
#         super(CosineClassifier, self).__init__()
#         self.device = 'cuda'
#         self.n_classes = 0
#         self._weights = nn.ParameterList([])
#         self.proxy_per_class = 10
#         self.features_dim = features_dim
#         self.bias = None
#         self.scaling = 3.
#         self.gamma = 1.
        
#         # adaptive alpha in eqn. 6. New alpha vectors are added in func `self.add_classes()`
#         self._alpha = nn.ParameterList([])  
#         # self.register_buffer('_alpha', )
        
    
#     @property
#     def weights(self):
#         return torch.cat([_weight for _weight in self._weights])
    
#     @property
#     def new_weights(self):
#         return self._weights[-1]
    
#     @property
#     def alpha(self):
#         return torch.cat([_alpha for _alpha in self._alpha])
#     def forward(self, features):
#         features = self.scaling * F.normalize(features, p=2, dim=-1)
#         weights = self.scaling * F.normalize(self.weights, p=2, dim=-1)
#         raw_similarities = -stable_cosine_distance(features, weights)

#         if self.proxy_per_class > 1:
#             n_classes = raw_similarities.shape[1] // self.proxy_per_class
#             bsz = raw_similarities.shape[0]
#             simi_per_class = raw_similarities.view(bsz, n_classes, self.proxy_per_class)

#             # 确保 self.alpha 的大小与类别数匹配
#             attentions = F.softmax(self.alpha.unsqueeze(1).repeat(1, self.proxy_per_class) * simi_per_class, dim=-1)
#             logits = (simi_per_class * attentions).sum(-1)
#         else:
#             logits = raw_similarities

#         return logits
#     # def forward(self, features):
#     #     weights = self.weights
        
#     #     features = self.scaling * F.normalize(features, p=2, dim=-1)
#     #     weights = self.scaling * F.normalize(weights, p=2, dim=-1)
#     #     raw_similarities = -stable_cosine_distance(features, weights)
        
#     #     if self.proxy_per_class > 1:
#     #         similarities = self._reduce_proxies(raw_similarities)
#     #     else:
#     #         similarities = raw_similarities
        
#     #     return {"logits": similarities, "raw_logits": raw_similarities}
    
#     def add_classes(self, n_classes):
#         logger.info(f'add_class: old classes: {self.n_classes}, new classes: {n_classes}')
#         ## add new weight
#         new_weights = nn.Parameter(torch.zeros(self.proxy_per_class * n_classes, self.features_dim))
#         nn.init.kaiming_normal_(new_weights, nonlinearity="linear")
#         self._weights.append(new_weights)

#         ## add new alpha
#         new_alpha = nn.Parameter(torch.zeros(n_classes))
#         nn.init.normal_(new_alpha)
#         self._alpha.append(new_alpha)
        
#         self.to(self.device)
#         self.n_classes += n_classes
        
    
    
#     def _reduce_proxies(self, similarities):
#         """
#           similarities : (batch_size, n_classes * proxy_per_class)
#              return    : (batch_size, n_classes)
#         """
#         n_classes = similarities.shape[1] / self.proxy_per_class
#         assert n_classes.is_integer(), (similarities.shape[1], self.proxy_per_class)
#         n_classes = int(n_classes)
#         bsz = similarities.shape[0]
        
#         simi_per_class = similarities.view(bsz, n_classes, self.proxy_per_class)
        
#         # 1. adaptive balanced softmax
#         # attentions = F.softmax(self.alpha.unsqueeze(1).tile(1, self.proxy_per_class) * simi_per_class, dim=-1) 
#         attentions = F.softmax(self.alpha.unsqueeze(1).repeat(1, self.proxy_per_class) * simi_per_class, dim=-1) 
        
#         # 2. vanilla softmax
#         # attentions = F.softmax(self.gamma * simi_per_class, dim=-1)  
        
#         return (simi_per_class * attentions).sum(-1)
    
    
# if __name__ == "__main__":
#     cosincls = CosineClassifier()
#     #print(cosincls.__dict__)
#     cosincls.add_classes(10)