from copy import deepcopy
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from sklearn.mixture import GaussianMixture
from training import train_step, model_bias, validate

import warnings
warnings.filterwarnings("ignore")

class Clients:
    def __init__(self, traindata, traintargets, idcs):
        self.traindata, self.traintargets, self.idcs = traindata, traintargets, idcs
        self.clean_data = torch.empty((0, *traindata[0].shape))
        self.clean_targets = torch.empty(0, dtype=torch.long)
        self.clean_idcs = torch.empty(0, dtype=torch.long)
        self.noisy_data = torch.empty((0, *traindata[0].shape))
        self.noisy_targets = torch.empty(0, dtype=torch.long)
        self.noisy_idcs = torch.empty(0, dtype=torch.long)
        self.trainset, self.cleanset = None, None
        self.datasize= None  # 初始化 datasize 属性
    def dynamic_update(self,model,dynamic_data, noisy_dynamic_targets, dynamic_idcs):
        self.traindata.extend(dynamic_data)
        self.traintargets = np.concatenate([self.traintargets, noisy_dynamic_targets])
        self.idcs = np.concatenate([self.idcs, dynamic_idcs])

        self.trainset = TensorDataset(torch.stack(self.traindata),
                                      torch.as_tensor(self.traintargets, dtype=torch.long),
                                      torch.as_tensor(self.idcs, dtype=torch.long))

        # 获取新类别的数量
        new_classes = len(np.unique(noisy_dynamic_targets))

        # 更新分类器中的类别数
        # model.cosine_classifier.add_classes(new_classes)
        if new_classes:
            # print(f"Client {self.idcs}: New classes detected, updating classifier.")
            model.adjust_classifier(new_classes)
            # print(f"After add_classes(10): weights shape {model.cosine_classifie.weights.shape}, alpha shape {model.cosine_classifie.alpha.shape}")





    def train(self, args, model,teacher_model, loss_fn, device, local_update, client_idx, t):
        model = model.to(device)
        
        global_dict = deepcopy(model.state_dict())


        # optimizer select
        if args.optimizer == 'SGD':
            # base_optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=1e-4)
            model_optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=1e-4)
            # model_optimizer= SAM(model.parameters(), base_optimizer, lr=args.lr, momentum=0.9, weight_decay=1e-5)
        elif args.optimizer == 'Adam':
            # base_optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-5)
            model_optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=1e-4)
            # model_optimizer = SAM(model.parameters(), base_optimizer, lr=args.lr, momentum=0.9, weight_decay=1e-5)
        else:
            model_optimizer = None

        # noise filtering
        # model.eval()
        # traindata = self.trainset.tensors[0]
        # traintargets = self.trainset.tensors[1]
        # trainidcs = self.trainset.tensors[2]
        # traindata, traintargets, trainidcs = traindata.to(device), traintargets.to(device), trainidcs.to(device)

        # step 1: noise filtering based on logits consistency and confidence
        # with torch.no_grad():
        #     losses = []
        #     if len(traindata) > 0:
        #         for i in range(traindata.size(0)):
        #             data = traindata[i].unsqueeze(0)
        #             target = traintargets[i].unsqueeze(0)
        #
        #             logits_model, logits_guida = model(data), guida_model(data)
        #             loss_model = loss_fn(logits_model, target)
        #             loss_guida = loss_fn(logits_guida, target)
        #             loss_add = loss_model + loss_guida
        #             losses.append(loss_add.item())
        #
        #         losses = np.array(losses).reshape(-1, 1)
        #         gmm = GaussianMixture(n_components=2, covariance_type='full', random_state=666666)
        #         gmm.fit(losses)
        #         means = gmm.means_
        #         clean_component = 0 if means[0] < means[1] else 1
        #         probs = gmm.predict_proba(losses)
        #         clean_mask1 = probs[:, clean_component] > args.min_threshold
        #
        #         # data classification
        #         self.clean_data = torch.cat([self.clean_data, traindata[clean_mask1].cpu()])
        #         self.clean_targets = torch.cat([self.clean_targets, traintargets[clean_mask1].cpu()])
        #         self.clean_idcs = torch.cat([self.clean_idcs, trainidcs[clean_mask1].cpu()])
        #
        #         self.noisy_data = torch.cat([self.noisy_data, traindata[~clean_mask1].cpu()])
        #         self.noisy_targets = torch.cat([self.noisy_targets, traintargets[~clean_mask1].cpu()])
        #         self.noisy_idcs = torch.cat([self.noisy_idcs, trainidcs[~clean_mask1].cpu()])
        #
        # step 2: Pseudo-label generation by model prediction
        # with torch.no_grad():
        #     clean_mask2 = torch.zeros(len(self.noisy_targets), dtype=torch.bool)
        #     for idx in range(len(self.noisy_targets)):
        #         data = self.noisy_data[idx].unsqueeze(0).to(device)
        #         logits_model = model(data)
        #         confidence = torch.max(torch.softmax(logits_model, dim=1)).item()
        #         if confidence > args.max_threshold:
        #             clean_mask2[idx] = True
        #
        #     if clean_mask2.sum() > 0:
        #         pseudo_labels = torch.argmax(model(self.noisy_data[clean_mask2].to(device)), dim=1)
        #         pseudo_labels = pseudo_labels.to(self.clean_targets.dtype).cpu()
        #         self.clean_data = torch.cat([self.clean_data, self.noisy_data[clean_mask2].cpu()])
        #         self.clean_targets = torch.cat([self.clean_targets, pseudo_labels])
        #         self.clean_idcs = torch.cat([self.clean_idcs, self.noisy_idcs[clean_mask2].cpu()])
        #
        #     self.noisy_data = self.noisy_data[~clean_mask2].cpu()
        #     self.noisy_targets = self.noisy_targets[~clean_mask2].cpu()
        #     self.noisy_idcs = self.noisy_idcs[~clean_mask2].cpu()
        #
        # # update cleanset and trainset
        # self.traindata = []
        # self.traintargets = np.array([])
        # self.idcs = np.array([])
        #
        # local_data = torch.cat([self.clean_data, self.noisy_data])
        # local_targets = torch.cat([self.clean_targets, self.noisy_targets])
        # local_idcs = torch.cat([self.clean_idcs, self.noisy_idcs])
        #
        # self.cleanset = TensorDataset(local_data, local_targets, local_idcs)
        self.datasize = len(self.trainset)

        trainloader = DataLoader(self.trainset, batch_size=args.B, shuffle=True, num_workers=4)
        for i in range(args.E):
            train_step(trainloader, model, teacher_model, loss_fn, model_optimizer, device)

        local_update[str(client_idx)] = model_bias(model, global_dict)
        # print(f"local_update[{client_idx}]:", local_update.get(str(client_idx)))
        # print("local_update keys:", list(local_update.keys()))


    def upload(self):
        return self.datasize
class SAM(torch.optim.Optimizer):

    def __init__(self, params, base_optimizer, rho=0.05, adaptive=False, **kwargs):
        assert rho >= 0.0, f"Invalid rho, should be non-negative: {rho}"

        defaults = dict(rho=rho, adaptive=adaptive, **kwargs)
        super(SAM, self).__init__(params, defaults)

        self.base_optimizer = base_optimizer(self.param_groups, **kwargs)
        self.param_groups = self.base_optimizer.param_groups

    @torch.no_grad()
    def first_step(self, zero_grad=False):
        grad_norm = self._grad_norm()
        for group in self.param_groups:
            scale = group["rho"] / (grad_norm + 1e-12)

            for p in group["params"]:
                if p.grad is None: continue
                self.state[p]["old_p"] = p.data.clone()
                e_w = (torch.pow(p, 2) if group["adaptive"] else 1.0) * p.grad * scale.to(p)
                p.add_(e_w)  # climb to the local maximum "w + e(w)"

        if zero_grad: self.zero_grad()

    @torch.no_grad()
    def second_step(self, zero_grad=False):
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None: continue
                p.data = self.state[p]["old_p"]  # get back to "w" from "w + e(w)"

        self.base_optimizer.step()  # do the actual "sharpness-aware" update

        if zero_grad: self.zero_grad()

    @torch.no_grad()
    def step(self, closure=None):
        # assert closure is not None, "Sharpness Aware Minimization requires closure, but it was not provided"
        # closure = torch.enable_grad()(closure)  # the closure should do a full forward-backward pass
        #
        # self.first_step(zero_grad=True)
        # closure()
        # self.second_step()
        raise NotImplementedError(
            "SAM doesn't work like the other optimizers, you should first call first_step and the second_step; see the documentation for more info.")

    def _grad_norm(self):
        shared_device = self.param_groups[0]["params"][
            0].device  # put everything on the same device, in case of model parallelism
        norm = torch.norm(
            torch.stack([
                ((torch.abs(p) if group["adaptive"] else 1.0) * p.grad).norm(p=2).to(shared_device)
                for group in self.param_groups for p in group["params"]
                if p.grad is not None
            ]),
            p=2
        )
        return norm

    def load_state_dict(self, state_dict):
        super().load_state_dict(state_dict)
        self.base_optimizer.param_groups = self.param_groups
