""" helper function

ref:
    https://github.com/AllFever/DeepHyperX-DCTN/blob/8b63316dee790f2557101c8c7a5c10cfdc800c50/vit_pytorch/morphFormer.py#L25
    https://github.com/samaonline/Orthogonal-Convolutional-Neural-Networks/blob/master/imagenet/utils.py


"""
"""
这段代码定义了一组用于实现正交性正则化的辅助函数，主要面向深度学习中的卷积神经网络（CNN）模型。
代码中包含两种不同的正则化方法及其相关实现，以及几个用于计算正交性度量的辅助
函数。接下来逐步分解代码，并总结其主要功能。
"""


import numpy as np

import torch
from torch.nn import functional as F
#from dataset import CIFAR100Train, CIFAR100Test

def dbt_orth(model, backbone="CNN1"):
    "基于DBT矩阵的正交性正则化"

    if backbone=="rebuffi":  # cifar100 检查后端是否为“rebuffi”模型，通常用于CIFAR-100数据集。
        # 通过调用conv_orth_dist函数计算模型第一个阶段中的每个卷积层的正交性损失，并求和，结果存储在diff变量中。
        diff = conv_orth_dist(model.network.convnet.stage_1.blocks[0].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_1.blocks[1].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_1.blocks[2].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_1.blocks[3].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_1.blocks[4].conv_a.weight, stride=1)
        # 对第二个阶段中的卷积层进行正交性损失计算，将结果添加到diff中。
        diff += conv_orth_dist(model.network.convnet.stage_2.blocks[0].conv_a.weight, stride=2) \
            + conv_orth_dist(model.network.convnet.stage_2.blocks[1].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_2.blocks[2].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_2.blocks[3].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_2.blocks[4].conv_a.weight, stride=1)
        # 类似地，计算第三个阶段的卷积层的正交性损失并累加到diff
        diff += conv_orth_dist(model.network.convnet.stage_3.blocks[0].conv_a.weight, stride=2) \
            + conv_orth_dist(model.network.convnet.stage_3.blocks[1].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_3.blocks[2].conv_a.weight, stride=1) \
            + conv_orth_dist(model.network.convnet.stage_3.blocks[3].conv_a.weight, stride=1) 
        # 计算第四个阶段的卷积层的正交性损失并添加到diff中。
        diff += conv_orth_dist(model.network.convnet.stage_4.conv_a.weight, stride=1)
        # 返回最终的正交性损失值。
        return diff
    
    elif backbone=="resnet18":  # imgnet-100, imgnet-1k 检查后端是否为“resnet18”模型，通常用于ImageNet数据集。
        # 计算并累加ResNet-18第一个层的两个卷积层的正交性损失。
        diff = conv_orth_dist(model.layer1[0].conv1.weight, stride=1) \
            + conv_orth_dist(model.layer1[1].conv1.weight, stride=1)

        diff += conv_orth_dist(model.layer2[0].conv1.weight, stride=2) \
            + conv_orth_dist(model.layer2[1].conv1.weight, stride=1)
                
        diff += conv_orth_dist(model.layer3[0].conv1.weight, stride=2) \
            + conv_orth_dist(model.layer3[1].conv1.weight, stride=1)
        
        diff += conv_orth_dist(model.layer4[0].conv1.weight, stride=2) \
            + conv_orth_dist(model.layer4[1].conv1.weight, stride=1)
        return diff
    # 如果提供的backbone参数既不是"rebuffi"也不是"resnet18"，则抛出异常。
    elif backbone == "CNN1":
        diff = conv_orth_dist(model.conv1[0].weight, stride=1) \
           + conv_orth_dist(model.conv2[0].weight, stride=1)
        return diff

    elif backbone == "CNN2":
        diff = conv_orth_dist(model.c1.weight, stride=1) \
               + conv_orth_dist(model.c2.weight, stride=1) \
               + conv_orth_dist(model.c3.weight, stride=1) \
               + conv_orth_dist(model.c4.weight, stride=1) \
               + conv_orth_dist(model.c5.weight, stride=1) \
               + conv_orth_dist(model.c6.weight, stride=1) \
               + conv_orth_dist(model.c7.weight, stride=1) \
               + conv_orth_dist(model.c8.weight, stride=1) \
               + conv_orth_dist(model.c9.weight, stride=1)
        return diff
    else:
        raise Exception('undefined backbone {}'.format(backbone))   
    # return diff


def ker_orth(model, backbone="CNN1"):
    "传统的基于核矩阵的正交正则化"
    # 结构与dbt_orth类似，使用orth_dist而不是conv_orth_dist来计算正交性损失
    
    if backbone=="rebuffi":  # cifar100  检查后端是否为“rebuffi”模型，通常用于CIFAR-100数据集
        # 通过调用orth_dist函数计算模型第一个阶段中的每个卷积层的正交性损失，并求和，结果存储在diff变量中。
        diff = orth_dist(model.network.convnet.stage_1.blocks[0].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_1.blocks[1].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_1.blocks[2].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_1.blocks[3].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_1.blocks[4].conv_a.weight, stride=1)

        # 同样，计算第二阶段的卷积层的正交性损失，并加到diff中。
        diff += orth_dist(model.network.convnet.stage_2.blocks[0].conv_a.weight, stride=2) \
            + orth_dist(model.network.convnet.stage_2.blocks[1].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_2.blocks[2].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_2.blocks[3].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_2.blocks[4].conv_a.weight, stride=1)
        # 类似地，计算第三个阶段的卷积层的正交性损失并累加到diff
        diff += orth_dist(model.network.convnet.stage_3.blocks[0].conv_a.weight, stride=2) \
            + orth_dist(model.network.convnet.stage_3.blocks[1].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_3.blocks[2].conv_a.weight, stride=1) \
            + orth_dist(model.network.convnet.stage_3.blocks[3].conv_a.weight, stride=1) 
        # 计算第四个阶段的卷积层的正交性损失并添加到diff中
        diff += orth_dist(model.network.convnet.stage_4.conv_a.weight, stride=1)
        # 返回最终的正交性损失值
        return diff
    
    elif backbone=="resnet18":  # imgnet-100, imgnet-1k 检查后端是否为“resnet18”模型，通常用于ImageNet数据集。
        # 计算并累加ResNet-18第一个层的两个卷积层的正交性损失，并存储在diff变量中。
        diff = orth_dist(model.layer1[0].conv1.weight, stride=1) \
            + orth_dist(model.layer1[1].conv1.weight, stride=1)
        # 计算并累加ResNet-18第二个层的两个卷积层的正交性损失，并添加到diff中。
        diff += orth_dist(model.layer2[0].conv1.weight, stride=2) \
            + orth_dist(model.layer2[1].conv1.weight, stride=1)
        # 计算并累加ResNet-18第三个层的两个卷积层的正交性损失，并添加到diff中。
        diff += orth_dist(model.layer3[0].conv1.weight, stride=2) \
            + orth_dist(model.layer3[1].conv1.weight, stride=1)
        # 计算并累加ResNet-18第四个层的两个卷积层的正交性损失，并添加到diff中。
        diff += orth_dist(model.layer4[0].conv1.weight, stride=2) \
            + orth_dist(model.layer4[1].conv1.weight, stride=1)
        # 返回最终的正交性损失值
        return diff
    elif backbone == "CNN1":
        diff = orth_dist(model.conv1[0].weight, stride=1) \
           + orth_dist(model.conv2[0].weight, stride=1)
        return diff

    elif backbone == "CNN2":
        diff = orth_dist(model.c1.weight, stride=1) \
               + orth_dist(model.c2.weight, stride=1) \
               + orth_dist(model.c3.weight, stride=1) \
               + orth_dist(model.c4.weight, stride=1) \
               + orth_dist(model.c5.weight, stride=1) \
               + orth_dist(model.c6.weight, stride=1) \
               + orth_dist(model.c7.weight, stride=1) \
               + orth_dist(model.c8.weight, stride=1) \
               + orth_dist(model.c9.weight, stride=1)
        return diff

    # 如果模型的后端不是“resnet18”或“resnet50”，则抛出异常。
    else:
        raise Exception('undefined backbone {}'.format(backbone))   
    
    # return diff

# 辅助函数
def conv_orth_dist(kernel, stride = 1): # 定义了 conv_orth_dist 函数，接受两个参数：kernel（卷积核）和 stride（步幅，默认值为1）。
    "计算给定卷积核的正交性度量"
    [o_c, i_c, w, h] = kernel.shape # 将输入的卷积核的形状解包为输出通道数（o_c）、输入通道数（i_c）、宽度（w）和高度（h）。
    assert (w == h),"Do not support rectangular kernel" # 确保卷积核是正方形的（宽度等于高度）。如果不是，则抛出异常。
    #half = np.floor(w/2)
    assert stride<w,"Please use matrix orthgonality instead" # 验证步幅 stride 是否小于卷积核的宽度 w，以确保后续计算的有效性。
    new_s = stride*(w-1) + w  # 通过考虑步幅和卷积核的宽度，计算出一个新的大小 new_s，这是用于后续构建矩阵的大小。
    # 通过考虑步幅和卷积核的宽度，计算出一个新的大小 new_s，这是用于后续构建矩阵的大小。
    temp = torch.eye(new_s*new_s*i_c).reshape((new_s*new_s*i_c, i_c, new_s,new_s)).cuda()

    # 使用 PyTorch 的 F.conv2d 函数对 temp 和卷积核 kernel 进行卷积操作，结果被重塑为适合的形状。
    out = (F.conv2d(temp, kernel, stride=stride)).reshape((new_s*new_s*i_c, -1))
    Vmat = out[np.floor(new_s**2/2).astype(int)::new_s**2, :] # 通过选取 out 中的特定行来提取部分信息，形成新的矩阵 Vmat。

    # 创建一个全零矩阵 temp，其形状为 (i_c, i_c*new_s**2)，并根据公式填充目标值。
    temp= np.zeros((i_c, i_c*new_s**2))
    for i in range(temp.shape[0]):temp[i,np.floor(new_s**2/2).astype(int)+new_s**2*i]=1
    # 计算 Vmat 和 out 的转置的乘积与目标矩阵 temp 之间的差的 Frobenius 范数，作为正交性度量返回。
    return torch.norm( Vmat@torch.t(out) - torch.from_numpy(temp).float().cuda() )

  
def deconv_orth_dist(kernel, stride = 2, padding = 1):
    "针对反卷积操作计算正交性度量"
    [o_c, i_c, w, h] = kernel.shape  # 将反卷积核的形状解包为：输出通道数 (o_c)、输入通道数 (i_c)、宽度 (w) 和高度 (h)。
    # 使用输入的 kernel 对自身作卷积运算，结果存储在 output 中，同时指定步幅和填充。
    output = torch.conv2d(kernel, kernel, stride=stride, padding=padding)
    # 构造一个零矩阵 target，其形状与 output 相同。这个矩阵将在后续步骤中被更新以表示目标正交性。
    target = torch.zeros((o_c, o_c, output.shape[-2], output.shape[-1])).cuda()
    # 计算输出矩阵的中心位置。
    ct = int(np.floor(output.shape[-1]/2))
    # 将 target 在中心位置填充为单位矩阵，以表示期望的正交性结构。
    target[:,:,ct,ct] = torch.eye(o_c).cuda()
    # 计算 output 和 target 之间的 Frobenius 范数，作为反卷积操作的正交性度量并返回。
    return torch.norm( output - target )

   
def orth_dist(mat, stride=None):
    "计算任意矩阵的正交性损失"
    mat = mat.reshape( (mat.shape[0], -1) )  # 将输入矩阵 mat 重新塑形，以便将其通道数分开，便于后续计算。
    if mat.shape[0] < mat.shape[1]:
        mat = mat.permute(1,0)  # 若矩阵的行数小于列数，则转置矩阵，以确保后续计算的正确性。
    # 计算矩阵的转置与其自身的乘积，减去单位矩阵，得到的矩阵的 Frobenius 范数即为正交性损失，并返回该值。
    return torch.norm( torch.t(mat)@mat - torch.eye(mat.shape[1]).cuda())


